﻿
	<?php
	$logout=$this->input->get('logout');
	if($logout){
		echo "<div style='text-align:center;' class='alert alert-success'>".'you are successfully logged out'."</div>";
	}else{
		getInformUser();
	}
	?>




<div class="em-wrapper-main">
                    <div class="container container-main">
                        <div class="em-inner-main">
                            <div class="em-wrapper-area02"></div>
                            <div class="em-main-container em-col1-layout">
                                <div class="row">
                                    <div class="em-col-main col-sm-24">
                                        <div class="account-login">
                                            <div class="page-title em-box-02">
                                                <div class="title-box">
                                                    <h1></h1>
                                                </div>
                                            </div>
                                          
                                                <div class="col2-set">
                                                    
                                                               <h1>Who we are</h1>
<ul style="font-size: 18px;">
<li style="font-weight: 400;"><span style="font-weight: 400;"> &gt; We at chawrionline.com THE PAPER EXCHANGE offer last minute connectivity to every requirement of paper board to each and every buyer</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;"> &gt; 24x7 access to largest inventories of paper board across the country</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;"> &gt; www.chawrionline.com is the only market place to offer CREDIT to CASH</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;"> &gt; the only platform for traders to offer their stocks to all end use buyers</span></li>
<li style="font-weight: 400;"><span style="font-weight: 400;"> &gt; Founded and managed by Rakesh Agarwal of Agarwal Agencies Pvt. Ltd. Delhi and Shyam Gupta of Import Export Sales Co. of Delhi having &nbsp; &nbsp;more than 60 years of combined experience of the paper board industry</span></li>
</ul>
                                                               

                                                    
                                                    
                                                    
                                                    </div>
                                                </div>
                                            </form>
                                        </div><!-- /.account-login -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


               