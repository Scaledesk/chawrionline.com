﻿
	<?php
    $logout=$this->input->get('logout');
    if($logout){
        echo "<div style='text-align:center;' class=' container alert alert-success'>".'you are successfully logged out'."</div>";
    }else{
        getInformUser();
    }
    ?>




<div class="em-wrapper-main">
                    <div class="container container-main">
                        <div class="em-inner-main">
                            <div class="em-wrapper-area02"></div>
                            <div class="em-main-container em-col1-layout">
                                <div class="row">
                                    <div class="em-col-main col-sm-24">
                                        <div class="account-login">
                                            <div class="page-title em-box-02">
                                                <div class="title-box">
                                                    <h1></h1>
                                                </div>
                                            </div>
                                          
                                                <div class="col2-set">
                                                    <div class="col-md-24 ">
                                                    <div class="content">
                                                               <h1> Chawri Online </h1>
                                                               <h2> How It Works </h2>

                                                               <p >
                                                                   <ul style="font-size:15px;">
<li><i class="fa fa-circle"></i>&nbsp;&nbsp;Seller has to pay a fee of Rs.1000.00 (one thousand) per year in order to become an online seller at <a href="http://chawrionline.com/">chawrionline.com</a></li>
<li><i class="fa fa-circle"></i>&nbsp;&nbsp;Seller gets a unique login id and password and can upload unlimited stocks available on offer on<a href="http://chawrionline.com/">chawrionline.com</a></li>
<li><i class="fa fa-circle"></i>&nbsp;&nbsp;Buyer can access the huge inventory on offer by creating a FREE unique username login/password and can pick and chose whatever he wants to buy from the offered material on <a href="http://chawrionline.com/">chawrionline.com</a></li>
<li><i class="fa fa-circle"></i>&nbsp;&nbsp;Buyer will get a selection of material available based on Generic grade name, Brand and Manufacturer, common trade specifications, location, delivery period and Price</li>
<li><i class="fa fa-circle"></i>&nbsp;&nbsp;Once he chooses the material, a Performa invoice would be made for the amount payable</li>
<li><i class="fa fa-circle"></i>&nbsp;&nbsp;Buyer would have the choice of paying on FOR (freight paid) or FOB (self pick-up)basis as per his choice</li>
<li><i class="fa fa-circle"></i>&nbsp;&nbsp;Buyer has to make payment in the given bank account of <a href="http://chawrionline.com/">chawrionline.com</a> at the next banking opportunity available and upload proof of payment on <a href="http://chawrionline.com/">chawrionline.com</a></li>
<li><i class="fa fa-circle"></i>&nbsp;&nbsp;Once the payment is received from the buyer, the seller will be informed by <a href="http://chawrionline.com/">chawrionline.com</a> to raise invoice on the buyer directly and despatch/ready the material as chosen by the buyer</li>
<li><i class="fa fa-circle"></i>&nbsp;&nbsp;The seller will get two working days to despatch the goods from the time of receipt of payment confirmation</li>
<li><i class="fa fa-circle"></i>&nbsp;&nbsp;The seller has to update real time status on <a href="http://chawrionline.com/">chawrionline.com</a> once order confirmation is received, invoice is generated and material is despatched</li>
<li><i class="fa fa-circle"></i>&nbsp;&nbsp;Promised delivery period&nbsp; from the time of receipt of payment confirmation would be within 3 working days for distance up to 70kms (Delhi-NCR), 8 days for distance up to 1000kms, 12 days for distance up to 1500kms and 15 days for distance above 1500kms.</li>
<li><i class="fa fa-circle"></i>&nbsp;&nbsp;Once the material is picked by/delivered to buyer the seller has to login on <a href="http://chawrionline.com/">chawrionline.com</a> and inform material delivered</li>
<li><i class="fa fa-circle"></i>&nbsp;&nbsp;The buyer will get a 3 day window once the material is delivered to him to raise an issue if any (quality, quantity, specs or any other discrepancies)</li>
<li><i class="fa fa-circle"></i>&nbsp;&nbsp;The seller will get the due payment in his bank account on 4<sup>th</sup>day (subject to no issues raised by the buyer)</li>
<li><i class="fa fa-circle"></i>&nbsp;&nbsp;    In case of any issue raised by the buyer, first opportunity will be given to the seller to directly resolve and close it, albeit the experienced team of <a href="http://chawrionline.com/">chawrionline.com</a> will always be available if required</li>
</ul>
                                                               </p>
                                                               

                                                     </div>  
                                                        </div>
                                                    
                                                    
                                                    </div>
                                                </div>
                                            </form>
                                        </div><!-- /.account-login -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


               